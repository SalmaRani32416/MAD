import React, { useState } from 'react';
import { View, Text, Modal, Button } from 'react-native';

export default function App() {
  const [show, setShow] = useState(false);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Button title="Open Modal" onPress={() => setShow(true)} />

      <Modal visible={show} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
          <View style={{ backgroundColor: 'white', padding: 30, borderRadius: 10 }}>
            <Text>Hello from Modal!</Text>
            <Button title="Close" onPress={() => setShow(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}